<?php

namespace JRobo;


class Runner extends Robo\Runner
{

}
