<?php
if (!defined('JPATH_BASE'))
{
    define('JPATH_BASE', dirname(dirname(__DIR__)));
}
